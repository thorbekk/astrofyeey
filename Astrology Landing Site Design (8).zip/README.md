
  # Astrology Landing Site Design

  This is a code bundle for Astrology Landing Site Design. The original project is available at https://www.figma.com/design/Dny2lPUBhwlB0rMX96BnkY/Astrology-Landing-Site-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  